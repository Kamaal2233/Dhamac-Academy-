function redirectToCourse(courseName) {
    window.location.href = `course.html?course=${courseName}`;
}